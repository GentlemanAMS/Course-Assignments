README.md

A M S Arun Krishna
EE19B001
21st May 2021
Assignment 9 Discrete Fourier Transform

Input:
python3 EE2703_ASSIGN9_EE19B001.py

Output:
time interval: [-1pi, 1pi) Error = 0.006496802750855624
time interval: [-2pi, 2pi) Error = 1.5607475312151564e-09
time interval: [-3pi, 3pi) Error = 2.5979218776228663e-14
time interval: [-4pi, 4pi) Error = 8.881784197001252e-16
time interval: [-5pi, 5pi) Error = 1.6653345369377348e-14
time interval: [-6pi, 6pi) Error = 1.3988810110276972e-14

