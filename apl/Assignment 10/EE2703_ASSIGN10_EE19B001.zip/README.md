README.md

A M S Arun Krishna
EE19B001
2nd June 2021
Assignment 10 Spectra of Non-periodic signals

Input:
python3 EE2703_ASSIGN10_EE19B001.py

Output:
frequency =  1.1813879058775436
phase =  2.5259153550994355

Estimations for cos(freq*t + phase) without hamming:
Estimated frequency: 1.216832717533914
Estimated phase: 2.513421114763475

Estimations for cos(freq*t + phase) with hamming:
Estimated frequency: 1.1693144813335308
Estimated phase: 2.5250160009660996

Estimations for cos(freq*t + phase) with noise without hamming:
Estimated frequency: 1.2173527766443892
Estimated phase: 2.508232171427692

Estimations for cos(freq*t + phase) with noise with hamming:
Estimated frequency: 1.169521469282929
Estimated phase: 2.534420646153369

