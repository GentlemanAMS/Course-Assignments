README.md

A M S Arun Krishna
EE19B001
7th May 2021
Assignment 8 Circuit Analysis Using Sympy

Input:
python3 EE2703_ASSIGN8_EE19B001.py

Output:
R1 = 10k ohms
R2 = 10k ohms
C1 = 10nF
C2 = 10nF
G = 1.586
H(s) = 
0.0001*(1.586e-15*s**3 + 4.758e-10*s**2 + 4.758e-5*s + 1.586)/(2.0e-29*s**5 + 1.0414e-23*s**4 + 2.12419999999999e-18*s**3 + 2.12419999999999e-13*s**2 + 1.0414e-8*s + 0.0002)
R1 = 10k ohms
R3 = 10k ohms
C1 = 10pF
C2 = 10pF
G = 1.586
H(s) = 
1.0e-9*s*(1.586e-20*s**4 + 4.758e-15*s**3 + 4.758e-10*s**2 + 1.586e-5*s)/(2.0e-29*s**5 + 1.0414e-23*s**4 + 2.12419999999999e-18*s**3 + 2.12419999999999e-13*s**2 + 1.0414e-8*s + 0.0002)

