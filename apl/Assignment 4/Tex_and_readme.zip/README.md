Arun Krishna AMS
EE19B001

The following command has to be executed in the terminal
python3 EE2703_Ass4_EE19B001.py

The following output can be observed
Max deviation in estimation of exp(x) is 1.3327308703354248
Max deviation in estimation of cos(cos(x)) is 2.682986310394032e-15


